/**
 * binary search
 */

function binarySearch(arr, search){
  // tulis code di sini

}

let angka = [1,3,6,9,10,11,12,16,20,25,40,50,60,78,95,100];

console.log('9 : ', binarySearch(angka, 9));
console.log('25 : ', binarySearch(angka, 25));
console.log('80 : ', binarySearch(angka, 80));
console.log('95 : ', binarySearch(angka, 95));