/**
 * selection sort (asc / desc)
 */

function selectionSortAsc(arr){
  // tulis code di sini

}

function selectionSortDesc(arr){
  // tulis code di sini

}

let angka = [1,5,23,3,5,6,3,3,45,6,53,2,6,34,523,912];

console.log('dari kecil ke besar :', selectionSortAsc($angka));

console.log('dari besar ke kecil :', selectionSortDesc($angka));