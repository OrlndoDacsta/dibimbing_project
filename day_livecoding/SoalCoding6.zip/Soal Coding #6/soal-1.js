/**
 * Bubble sort (asc / desc)
 */

function bubbleSortAsc(arr){
  // tulis code di sini

}

function bubbleSortDesc(arr){
  // tulis code di sini

}

let angka = [1,5,23,3,5,6,3,3,45,6,53,2,6,34,523,912];

console.log('dari kecil ke besar :', bubbleSortAsc($angka));

console.log('dari besar ke kecil :', bubbleSortDesc($angka));