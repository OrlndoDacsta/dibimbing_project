function nilaiTempat(number) {
  const digits = String(number);
  for (let i = 0; i < digits.length; i++) {
    const placeValue = parseInt(digits[i]) * Math.pow(10, digits.length - 1 - i);
    console.log(placeValue);
  }
}
nilaiTempat(123);
console.log('-------------------------');
nilaiTempat('13452');