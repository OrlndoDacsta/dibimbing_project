/**
 * Factorial:
 * - input 4, akan memiliki output 4*3*2*1 = 24
 * - input 2, akan memiliki output 2*1 = 2
 * - pengecualian: 0 faktorial = 1
 */

function factorial(num){
  // tulis code di sini
  if (num === 0 || num === 1) {
    return 1;
  }

  return num * factorial(num - 1);
}

console.log(factorial(0)); // 1
console.log(factorial(1)); // 1
console.log(factorial(2)); // 2
console.log(factorial(4)); // 24
console.log(factorial(6)); // 720
console.log(factorial(10)); // 3628800