/**
 * Menampilkan komponen "nilai tempat" dari suatu bilangan, contoh:
 * input: 123 (dalam bentuk number/string)
 * akan memunculkan ( console.log() ) :
 * 100
 * 20
 * 3
 */

function nilaiTempat(number) {

  number = `${number}`;

  if (number.length <= 1) {
    console.log(number);
  }
  else {

    let show = '';
    let rest = '';

    for (let i = 0; i < number.length; i++) {
      if (i === 0) {
        show += number[i];
      }
      else {
        show += '0';
        rest += number[i];
      }
    }
    
    console.log(show);

    nilaiTempat(rest);
  }
}

// expected output:
// 100
// 20
// 3
// -------------------------
// 10000
// 3000
// 400
// 50
// 2


nilaiTempat(123);
console.log('-------------------------');
nilaiTempat('13452');