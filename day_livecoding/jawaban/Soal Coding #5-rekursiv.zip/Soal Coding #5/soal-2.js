/**
 * Menampilkan komponen "nilai tempat" dari suatu bilangan, contoh:
 * input: 123 (dalam bentuk number/string)
 * akan memunculkan ( console.log() ) :
 * 100
 * 20
 * 3
 */

function nilaiTempat(number) {
  // tulis code di sini
  number = `${number}`;

  if (number.length === 1 || number.length === 0) {
    console.log(number);
  }
  else {
    let angka = '';
    let sisanya = '';
    for (let i = 0; i < number.length; i++) {
      if (i === 0) {
        angka += number[i];
      }
      else {
        angka += '0';
        sisanya += number[i];
      }
    }
    
    console.log(angka);

    nilaiTempat(sisanya);
  }
}

// expected output:
// 100
// 20
// 3
// -------------------------
// 10000
// 3000
// 400
// 50
// 2

nilaiTempat('827'); // 80
// 80
// 2


// nilaiTempat(123);
// console.log('-------------------------');
// nilaiTempat('13452');